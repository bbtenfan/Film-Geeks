package com.example.kaliman.filmgeeks.NetworkInterface;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.kaliman.filmgeeks.R;

public class OMDBNetworkInterface {

    private final String TAG = "OMDBNetworkInterface";
    private static OMDBNetworkInterface omdbNetworkInterface;
    private static Context myContext;
    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;

    private String url = "http://www.omdbapi.com/?apikey=1ebd6e3f";

    private OMDBNetworkInterface(Context context) {
        myContext = context;
    }

    public static OMDBNetworkInterface getInstance(Context context) {
        if (omdbNetworkInterface == null) {
            omdbNetworkInterface = new OMDBNetworkInterface(context);
        }

        return omdbNetworkInterface;
    }

    public void getMovies(String movieName) {

        if (movieName != null) {
            //build search request
            url += "&t="+movieName;
            Log.d(TAG, "search url:"+url);

            //RequestQueue initialized
            mRequestQueue = Volley.newRequestQueue(myContext);

            //String Request initialized
            mStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    //display the response on screen
                    Toast.makeText(myContext,"Response :" + response.toString(),
                            Toast.LENGTH_LONG).show();

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Log.i(TAG,"Error :" + error.toString());
                }
            });

            mRequestQueue.add(mStringRequest);
        }
    }
}
