package com.example.kaliman.filmgeeks;

import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kaliman.filmgeeks.NetworkInterface.OMDBNetworkInterface;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private AppBarLayout appBarLayout;
    private ViewPager viewPager;
    private Button findButton;
    private EditText searchBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tabLayout = (TabLayout) findViewById(R.id.tablayout_id);
        appBarLayout = (AppBarLayout) findViewById(R.id.appbar_id);
        searchBox = (EditText) findViewById(R.id.search_field_id);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        findButton = (Button) findViewById(R.id.search_button_id);

        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        //Adding Fragments
        adapter.addFragment(new SearchResultsFragment(), getString(R.string.search_tab_title));
        adapter.addFragment(new FavoritesFragment(), getString(R.string.favorites_tab_title));
        //Adapter setup
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        findButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if (searchBox != null && searchBox.getText().length() >= 2) {
                    OMDBNetworkInterface omdbNetworkInterface = OMDBNetworkInterface.getInstance(getApplicationContext());
                    omdbNetworkInterface.getMovies(searchBox.getText().toString());
                } else {
                    Toast.makeText(MainActivity.this, getText(R.string.not_enough_letters),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
